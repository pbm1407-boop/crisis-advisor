# Crisis Advisor — Deploy Guide

## What this is
An AI-powered crisis management chatbot for managers.
Describe your crisis, get an instant structured response: diagnosis, action plan, and communication strategy.

---

## Deploy to Vercel in 5 steps (no coding needed)

### Step 1 — Create a GitHub account
Go to github.com and sign up (free).

### Step 2 — Upload this project to GitHub
1. Go to github.com/new to create a new repository
2. Name it "crisis-advisor"
3. Click "Create repository"
4. Click "uploading an existing file"
5. Upload ALL the files from this folder (keep the folder structure exactly as is)
6. Click "Commit changes"

### Step 3 — Create a Vercel account
Go to vercel.com and sign up with your GitHub account (free).

### Step 4 — Deploy
1. On Vercel dashboard, click "Add New Project"
2. Select your "crisis-advisor" GitHub repository
3. Click "Deploy" — Vercel auto-detects Next.js

### Step 5 — Add your API key
1. After deploy, go to your project Settings
2. Click "Environment Variables"
3. Add: Name = ANTHROPIC_API_KEY, Value = (your key from platform.anthropic.com)
4. Click Save
5. Go to Deployments tab → click the 3 dots → Redeploy

Your app is now live at a public URL like: https://crisis-advisor-yourname.vercel.app

---

## Getting your Anthropic API key (free credits included)
1. Go to platform.anthropic.com
2. Sign up with email
3. Go to "API Keys" → "Create Key"
4. Copy the key and paste it into Vercel (Step 5 above)

---

## Folder structure
crisis-advisor/
├── pages/
│   ├── index.js        (the chat UI)
│   └── api/
│       └── chat.js     (server-side API call — your key is safe here)
├── package.json
└── README.md
