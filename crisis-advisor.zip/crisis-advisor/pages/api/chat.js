export default async function handler(req, res) {
  if (req.method !== "POST") return res.status(405).end();

  const { messages } = req.body;

  const SYSTEM_PROMPT = `You are a senior crisis management advisor with 20+ years of experience. You help managers inside companies navigate active crises — fast, specific, and strategic.

When a manager describes their crisis situation, respond with a tight, structured plan in this exact format:

🔴 CRISIS DIAGNOSIS
List 3 key risks. Each: risk name in caps — one sharp sentence on why it matters beyond the obvious.

⚡ IMMEDIATE ACTIONS (0–72 hours)
3 specific, realistic actions. No vague advice. Name who does what by when.

📅 SHORT-TERM PLAN (1–2 weeks)
3 actions. Focus on stabilisation and stakeholder management.

📣 COMMUNICATION STRATEGY
Internal: one specific action for employees.
External: one specific action for customers/public/government.
Never say this publicly: [complete with one specific line to avoid].

Keep responses concise and direct. You are advising someone under real time pressure. No academic language. No filler. If the manager asks a follow-up, answer sharply and specifically in context of their crisis.`;

  try {
    const response = await fetch("https://api.anthropic.com/v1/messages", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "x-api-key": process.env.ANTHROPIC_API_KEY,
        "anthropic-version": "2023-06-01",
      },
      body: JSON.stringify({
        model: "claude-haiku-4-5-20251001",
        max_tokens: 1000,
        system: SYSTEM_PROMPT,
        messages,
      }),
    });

    const data = await response.json();

    if (data.error) {
      return res.status(500).json({ error: data.error.message });
    }

    return res.status(200).json({ reply: data.content[0].text });
  } catch (err) {
    return res.status(500).json({ error: "Failed to reach AI. Check your API key in Vercel settings." });
  }
}
