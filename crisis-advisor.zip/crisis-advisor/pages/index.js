import { useState, useRef, useEffect } from "react";

const STARTERS = [
  "A chemical explosion near our factory has halted all operations",
  "Our product just went viral on social media for the wrong reasons",
  "Industrial waste from our facility has polluted a nearby river",
  "A data breach just exposed our customer information",
  "A key supplier shut down overnight with no warning",
  "Employee protest has blocked our factory entrance",
];

export default function Home() {
  const [messages, setMessages] = useState([]);
  const [input, setInput] = useState("");
  const [loading, setLoading] = useState(false);
  const [started, setStarted] = useState(false);
  const [error, setError] = useState("");
  const bottomRef = useRef(null);
  const inputRef = useRef(null);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages, loading]);

  async function send(text) {
    const userText = (text || input).trim();
    if (!userText || loading) return;
    setInput("");
    setError("");
    setStarted(true);

    const next = [...messages, { role: "user", content: userText }];
    setMessages(next);
    setLoading(true);

    try {
      const res = await fetch("/api/chat", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ messages: next }),
      });
      const data = await res.json();
      if (data.error) {
        setError(data.error);
      } else {
        setMessages([...next, { role: "assistant", content: data.reply }]);
      }
    } catch {
      setError("Connection failed. Please try again.");
    }

    setLoading(false);
    setTimeout(() => inputRef.current?.focus(), 100);
  }

  function handleKey(e) {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      send();
    }
  }

  function reset() {
    setMessages([]);
    setStarted(false);
    setInput("");
    setError("");
  }

  return (
    <>
      <style>{`
        * { box-sizing: border-box; margin: 0; padding: 0; }
        body { font-family: 'Segoe UI', system-ui, sans-serif; background: #f1f5f9; }
        html, body, #__next { height: 100%; }
        @keyframes bounce {
          0%, 60%, 100% { transform: translateY(0); opacity: 0.4; }
          30% { transform: translateY(-5px); opacity: 1; }
        }
        @keyframes fadeIn {
          from { opacity: 0; transform: translateY(6px); }
          to { opacity: 1; transform: translateY(0); }
        }
        .msg { animation: fadeIn 0.2s ease forwards; }
        ::-webkit-scrollbar { width: 4px; }
        ::-webkit-scrollbar-thumb { background: #cbd5e1; border-radius: 4px; }
        textarea:focus { outline: none; border-color: #94a3b8 !important; }
        .starter:hover { background: #f0f9ff !important; border-color: #7dd3fc !important; }
        .send-btn:hover:not(:disabled) { background: #1e3a5f !important; }
        .reset-btn:hover { color: #ef4444 !important; }
      `}</style>

      <div style={{ display: "flex", flexDirection: "column", height: "100vh" }}>

        {/* Header */}
        <div style={{ background: "#0f172a", padding: "14px 20px", display: "flex", alignItems: "center", gap: 12, flexShrink: 0 }}>
          <div style={{ width: 38, height: 38, borderRadius: "50%", background: "#1e293b", border: "1.5px solid #334155", display: "flex", alignItems: "center", justifyContent: "center" }}>
            <span style={{ color: "#38bdf8", fontWeight: 700, fontSize: 16, fontFamily: "Georgia, serif" }}>C</span>
          </div>
          <div>
            <div style={{ color: "#f1f5f9", fontWeight: 600, fontSize: 15 }}>Crisis Advisor</div>
            <div style={{ color: "#475569", fontSize: 12 }}>AI-powered · For managers under pressure</div>
          </div>
          <div style={{ marginLeft: "auto", display: "flex", alignItems: "center", gap: 12 }}>
            {started && (
              <button className="reset-btn" onClick={reset} style={{ background: "none", border: "none", color: "#64748b", fontSize: 12, cursor: "pointer", transition: "color 0.15s" }}>
                New crisis
              </button>
            )}
            <div style={{ display: "flex", alignItems: "center", gap: 5 }}>
              <div style={{ width: 7, height: 7, borderRadius: "50%", background: "#22c55e" }} />
              <span style={{ color: "#475569", fontSize: 12 }}>Online</span>
            </div>
          </div>
        </div>

        {/* Chat area */}
        <div style={{ flex: 1, overflowY: "auto", padding: "20px 16px", maxWidth: 720, width: "100%", margin: "0 auto" }}>

          {!started && (
            <div style={{ textAlign: "center", paddingTop: 32, paddingBottom: 24 }}>
              <div style={{ width: 60, height: 60, borderRadius: "50%", background: "#0f172a", display: "flex", alignItems: "center", justifyContent: "center", margin: "0 auto 16px" }}>
                <span style={{ color: "#38bdf8", fontWeight: 700, fontSize: 26, fontFamily: "Georgia, serif" }}>C</span>
              </div>
              <div style={{ fontSize: 20, fontWeight: 600, color: "#0f172a", marginBottom: 8 }}>What is the crisis?</div>
              <div style={{ fontSize: 14, color: "#64748b", marginBottom: 32, maxWidth: 320, margin: "0 auto 32px" }}>
                Describe what is happening right now. Get a full diagnosis and action plan in seconds.
              </div>
              <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 8, maxWidth: 520, margin: "0 auto" }}>
                {STARTERS.map((s, i) => (
                  <button key={i} className="starter" onClick={() => send(s)} style={{
                    background: "#fff", border: "1px solid #e2e8f0", borderRadius: 10,
                    padding: "10px 14px", fontSize: 12, color: "#334155",
                    cursor: "pointer", textAlign: "left", lineHeight: 1.5, transition: "all 0.15s"
                  }}>
                    {s}
                  </button>
                ))}
              </div>
            </div>
          )}

          {messages.map((msg, i) => {
            const isUser = msg.role === "user";
            return (
              <div key={i} className="msg" style={{ display: "flex", justifyContent: isUser ? "flex-end" : "flex-start", marginBottom: 16 }}>
                {!isUser && (
                  <div style={{ width: 32, height: 32, borderRadius: "50%", background: "#0f172a", border: "1.5px solid #1e3a5f", display: "flex", alignItems: "center", justifyContent: "center", marginRight: 10, flexShrink: 0, marginTop: 2 }}>
                    <span style={{ color: "#38bdf8", fontWeight: 700, fontSize: 13, fontFamily: "Georgia, serif" }}>C</span>
                  </div>
                )}
                <div style={{
                  maxWidth: "80%", padding: isUser ? "10px 14px" : "13px 16px",
                  borderRadius: isUser ? "18px 18px 4px 18px" : "4px 18px 18px 18px",
                  background: isUser ? "#0f172a" : "#fff",
                  border: isUser ? "none" : "1px solid #e2e8f0",
                  color: isUser ? "#f1f5f9" : "#1e293b",
                  fontSize: 14, lineHeight: 1.8, whiteSpace: "pre-wrap", wordBreak: "break-word"
                }}>
                  {msg.content}
                </div>
              </div>
            );
          })}

          {loading && (
            <div style={{ display: "flex", alignItems: "flex-start", marginBottom: 16 }}>
              <div style={{ width: 32, height: 32, borderRadius: "50%", background: "#0f172a", border: "1.5px solid #1e3a5f", display: "flex", alignItems: "center", justifyContent: "center", marginRight: 10, flexShrink: 0 }}>
                <span style={{ color: "#38bdf8", fontWeight: 700, fontSize: 13, fontFamily: "Georgia, serif" }}>C</span>
              </div>
              <div style={{ background: "#fff", border: "1px solid #e2e8f0", borderRadius: "4px 18px 18px 18px", padding: "13px 16px" }}>
                <div style={{ display: "flex", gap: 4 }}>
                  {[0,1,2].map(i => (
                    <div key={i} style={{ width: 6, height: 6, borderRadius: "50%", background: "#94a3b8", animation: "bounce 1.2s infinite", animationDelay: `${i*0.2}s` }} />
                  ))}
                </div>
              </div>
            </div>
          )}

          {error && (
            <div style={{ background: "#fef2f2", border: "1px solid #fecaca", borderRadius: 10, padding: "10px 14px", fontSize: 13, color: "#dc2626", marginBottom: 16 }}>
              {error}
            </div>
          )}

          <div ref={bottomRef} />
        </div>

        {/* Input */}
        <div style={{ background: "#fff", borderTop: "1px solid #e2e8f0", padding: "12px 16px", flexShrink: 0 }}>
          <div style={{ maxWidth: 720, margin: "0 auto" }}>
            {started && (
              <div style={{ fontSize: 11, color: "#94a3b8", textAlign: "center", marginBottom: 8 }}>
                Ask follow-up questions — I stay in context of your crisis
              </div>
            )}
            <div style={{ display: "flex", gap: 10, alignItems: "flex-end" }}>
              <textarea
                ref={inputRef}
                value={input}
                onChange={e => setInput(e.target.value)}
                onKeyDown={handleKey}
                placeholder="Describe what is happening right now..."
                rows={2}
                style={{
                  flex: 1, border: "1px solid #e2e8f0", borderRadius: 12,
                  padding: "10px 14px", fontSize: 14, resize: "none",
                  fontFamily: "inherit", color: "#1e293b", background: "#f8fafc", lineHeight: 1.5, transition: "border-color 0.15s"
                }}
              />
              <button
                className="send-btn"
                onClick={() => send()}
                disabled={!input.trim() || loading}
                style={{
                  width: 44, height: 44, borderRadius: "50%",
                  background: input.trim() && !loading ? "#0f172a" : "#e2e8f0",
                  border: "none", cursor: input.trim() && !loading ? "pointer" : "default",
                  display: "flex", alignItems: "center", justifyContent: "center",
                  flexShrink: 0, transition: "background 0.15s"
                }}>
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none">
                  <path d="M22 2L11 13" stroke={input.trim() && !loading ? "#fff" : "#94a3b8"} strokeWidth="2" strokeLinecap="round" />
                  <path d="M22 2L15 22L11 13L2 9L22 2Z" stroke={input.trim() && !loading ? "#fff" : "#94a3b8"} strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
                </svg>
              </button>
            </div>
            <div style={{ fontSize: 11, color: "#cbd5e1", textAlign: "center", marginTop: 8 }}>
              Enter to send · Shift+Enter for new line
            </div>
          </div>
        </div>

      </div>
    </>
  );
}
